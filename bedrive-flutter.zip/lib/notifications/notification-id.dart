class NotificationType {
  static const fileShared = 'A01';
  static const workspaceInvite = 'W01';
  static const transferProgress = 'L01';
}