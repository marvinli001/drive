enum EntryMoveType {
  move,
  copy,
}