const SEARCH_FILE_TYPES = <String, String>{
  'folder': 'Folders',
  'pdf': 'PDFs',
  'image': 'Photos & images',
  'word': 'Word Documents',
  'text': 'Text Files',
  'spreadsheet': 'Spreadsheets',
  'powerPoint': 'Presentations',
  'audio': 'Audio',
  'video': 'Video',
  'archive': 'Archives',
};
