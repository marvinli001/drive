import 'package:flutter/material.dart';

final shareableLinkFormKey = GlobalKey<FormState>();